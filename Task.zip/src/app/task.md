Description: You are tasked with building a Todo List application using AngularJS. The application should allow users to add, edit, and delete tasks. The tasks should be displayed in a list with the ability to mark them as completed. Additionally, the application should have the following features:

Task Filtering: Users should be able to filter tasks based on their completion status (All, Completed, Active).
Task Count: Display the total number of tasks and the number of completed tasks.
Local Storage: The application should persist the tasks in the browser's local storage so that the tasks are not lost on page refresh.

Requirements:

Use AngularJS framework to build the application.
Use AngularJS directives, controllers, and services as appropriate.
Use CSS to style the application.
Write clean and maintainable code with appropriate comments and documentation.
Implement error handling and validation where necessary.
Ensure the application is responsive and works well on different devices.

Feel free to use any additional libraries or frameworks that you think would enhance the application.

Submission: Please provide the source code of your solution along with any necessary instructions to run the application.
