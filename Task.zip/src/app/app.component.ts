import { Component , DoCheck , OnInit } from '@angular/core';
import { Card } from './card/card.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements DoCheck , OnInit{


  title = 'FirstApp';
  cards:Card[] = [];
  filterValue = "";
  completeCount = 0;

  sampleCard:Card = {
    status:false,
    description:"",
    title:""
  }
  isAddButtonClicked = false;

  ngOnInit(): void {
    this.cards = JSON.parse(localStorage.getItem('cards'));
  }

  addCard(){
    this.cards.push(this.sampleCard);
    this.sampleCard = {
      status:false,
      description:"",
      title:""
    }
    this.isAddButtonClicked=!this.isAddButtonClicked;
  }

  ngDoCheck(): void {
    if(this.cards.length>0){
      localStorage.setItem('cards',JSON.stringify(this.cards));
    }
    this.completeCount = this.cards.filter((card)=>card.status).length;
  }
}
