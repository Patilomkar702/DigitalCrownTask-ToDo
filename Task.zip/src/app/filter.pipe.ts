import { Pipe, PipeTransform } from '@angular/core';
import { Card } from './card/card.component';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(cards:Card[],property,filterVal): any {
    if(cards.length>0){
      return cards.filter((card)=>{

        return card[property].includes(filterVal);
      })
    }
    return null;
  }

}
