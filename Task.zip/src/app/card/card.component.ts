import { Component, OnInit , Input , Output, EventEmitter} from '@angular/core';

export interface Card {
  status:boolean;
  title:String;
  description:String
}

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {

  @Input("cardData") data:Card;
  @Output('cardDataChange') dataEmiiter:EventEmitter<Card>= new EventEmitter<Card>();
  isEdited=false;
  constructor() { }

  ngOnInit(): void {
  }

}
