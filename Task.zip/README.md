Steps to Run Application :

    1.opne Project in Any IDE

    2.Install Node Modules : npm i

    3.Run application : ng serve -o
    if Port is Running then used : ng servr -o --port

